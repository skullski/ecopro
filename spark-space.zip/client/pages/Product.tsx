import { useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";

const SAMPLE_PRODUCTS = [
  { id: "1", name: "قميص قطن", price: 19, desc: "قميص مريح عالي الجودة" },
  { id: "2", name: "حذاء رياضي", price: 59, desc: "حذاء خفيف للركض والمشي" },
  { id: "3", name: "قلم ذكي", price: 9, desc: "قلم عملي واستخدامي" },
];

export default function Product() {
  const { id } = useParams();
  const p = SAMPLE_PRODUCTS.find((x) => x.id === id);
  if (!p) return <div className="container mx-auto py-20">المنتج غير موجود</div>;

  function addToCart() {
    const cart = JSON.parse(localStorage.getItem("cart") || "[]");
    cart.push(p);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("تمت إضافة المنتج للسلة");
  }

  return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-3xl rounded-lg border bg-card p-6">
        <div className="h-64 w-full rounded-md bg-muted/30" />
        <h1 className="mt-4 text-2xl font-bold">{p.name}</h1>
        <p className="mt-2 text-muted-foreground">{p.desc}</p>
        <div className="mt-4 flex items-center gap-4">
          <div className="text-2xl font-extrabold">${p.price}</div>
          <Button onClick={addToCart}>أضف للسلة</Button>
        </div>
      </div>
    </section>
  );
}
