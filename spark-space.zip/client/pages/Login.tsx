import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";

export default function Login() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // simple demo auth
    const user = { email };
    localStorage.setItem("user", JSON.stringify(user));
    alert(t("login") + " successful");
    navigate("/app");
  }

  return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-md rounded-xl border bg-card p-8 shadow-sm">
        <h2 className="text-2xl font-bold mb-4">{t("login")}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm">البريد الإلكتروني</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm">كلمة المرور</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 w-full rounded-md border px-3 py-2" />
          </div>
          <div className="flex items-center justify-between">
            <Button type="submit">{t("login")}</Button>
            <Link to="/signup" className="text-sm text-primary">{t("signup")}</Link>
          </div>
        </form>
      </div>
    </section>
  );
}
