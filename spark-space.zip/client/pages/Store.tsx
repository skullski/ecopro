import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";

const SAMPLE_PRODUCTS = [
  { id: "1", name: "قميص قطن", price: 19 },
  { id: "2", name: "حذاء رياضي", price: 59 },
  { id: "3", name: "قلم ذكي", price: 9 },
];

export default function Store() {
  const { t } = useTranslation();
  const cart = JSON.parse(localStorage.getItem("cart") || "[]");

  function addToCart(p:any) {
    const cart = JSON.parse(localStorage.getItem("cart") || "[]");
    cart.push(p);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("تمت الإضافة إلى السلة");
  }

  return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-4xl">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold mb-6">{t("store.title")}</h2>
          <div>
            <Link to="/checkout" className="text-sm text-primary/90 underline">السلة ({cart.length})</Link>
          </div>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SAMPLE_PRODUCTS.map((p) => (
            <div key={p.id} className="rounded-lg border bg-card p-4">
              <div className="h-40 w-full rounded-md bg-muted/30" />
              <h3 className="mt-4 font-bold">{p.name}</h3>
              <div className="mt-2 flex items-center justify-between">
                <div className="text-lg font-extrabold">${p.price}</div>
                <div className="flex items-center gap-2">
                  <Link to={`/product/${p.id}`}>
                    <Button variant="ghost">عرض</Button>
                  </Link>
                  <Button onClick={() => addToCart(p)}>أضف للسلة</Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
