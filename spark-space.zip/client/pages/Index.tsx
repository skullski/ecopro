import { Button } from "@/components/ui/button";
import {
  Palette,
  ShoppingCart,
  CreditCard,
  Truck,
  Megaphone,
  BarChart3,
  Link2,
} from "lucide-react";
import { useTranslation } from "@/lib/i18n";

export default function Index() {
  const { t } = useTranslation();

  return (
    <div className="bg-background">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(1200px_600px_at_80%_-20%,hsl(var(--primary)/0.25),transparent),radial-gradient(1000px_400px_at_10%_-10%,hsl(var(--accent)/0.25),transparent)]" />
        <div className="container mx-auto px-4 py-20 sm:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full border bg-background/60 px-3 py-1 text-xs text-foreground/70 backdrop-blur">
              {t("hero.badge")}
            </div>
            <h1 className="mt-4 text-4xl font-extrabold leading-[1.15] tracking-tight sm:text-5xl">
              {t("hero.title")}
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">{t("hero.desc")}</p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <a href="#مزايا">
                <Button className="px-6">{t("cta.features")}</Button>
              </a>
              <a href="#الأسعار">
                <Button variant="outline" className="px-6">{t("cta.pricing")}</Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="مزايا" className="container mx-auto px-4 py-16 sm:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{t("features.title")}</h2>
          <p className="mt-3 text-muted-foreground">{t("features.desc")}</p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Feature icon={<Palette className="text-primary" />} title="قوالب وتصميم مرن" desc="اختر ��ن قوالب حديثة قابلة للتعديل بالكامل مع دعم كامل للهواتف." />
          <Feature icon={<ShoppingCart className="text-primary" />} title="إدارة المنتجات والطلبات" desc="لوحة تحكم بديهية لإضافة المنتجات ومتابعة الطلبات والمخزون." />
          <Feature icon={<CreditCard className="text-primary" />} title="مدفوعات آمنة" desc="تكامل مع بوابات دفع موثوقة ودعم عملات متعددة." />
          <Feature icon={<Truck className="text-primary" />} title="الشحن وتتبع الطلبات" desc="إدارة شركات الشحن وتتبع الشحنات تلقائيًا لعملائك." />
          <Feature icon={<Megaphone className="text-primary" />} title="التسويق والأتمتة" desc="كوبونات، رسائل بريدية، حملات إعلانية وربط منصات التواصل." />
          <Feature icon={<BarChart3 className="text-primary" />} title="تقارير وتحليلات" desc="لوحات تقارير فورية لقياس الأداء والمبيعات ونِسب التحويل." />
        </div>
      </section>

      {/* Architecture */}
      <section id="البنية" className="container mx-auto px-4 py-16 sm:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{t("architecture.title")}</h2>
          <p className="mt-3 text-muted-foreground">{t("features.desc")}</p>
        </div>
        <div className="mx-auto mt-12 grid max-w-5xl gap-6 lg:grid-cols-5">
          <Arch title="واجهة المتجر" desc="واجهة سريعة الاستجابة وقابلة للتخصيص بتجربة شراء سلسة." />
          <Arch title="لوحة التحكم" desc="إدارة مركزية للمحتوى والطلبات والعملاء والمنتجات." />
          <Arch title="واجهات API" desc="تكاملات موثوقة عبر REST/Webhooks لربط الخدمات الخارجية." />
          <Arch title="التكاملات" desc="بوابات دفع، شركات شحن، أدوات تحليلات وتسويق." />
          <Arch title="البيانات" desc="تخزين آمن ونسخ احتياطي وتشفير لحماية معلوماتك." />
        </div>
        <div className="mx-auto mt-8 flex max-w-2xl items-center justify-center gap-3 text-sm text-muted-foreground">
          <Link2 className="h-4 w-4 inline-block" />
          <span>كل الو��دات تعمل بتناغم لرحلة عميل مثالية من الاكتشاف حتى الدفع.</span>
        </div>
      </section>

      {/* Pricing */}
      <section id="الأسعار" className="container mx-auto px-4 py-16 sm:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{t("pricing.title")}</h2>
          <p className="mt-3 text-muted-foreground">ابدأ مجانًا ثم اختر الخطة التي تناسب نمو متجرك.</p>
        </div>
        <div className="mx-auto mt-12 grid max-w-5xl gap-6 md:grid-cols-2">
          <Plan
            name="مجاني"
            price="0"
            features={[
              "قالب أساسي",
              "حتى 50 منتجًا",
              "تقارير مختصرة",
            ]}
            cta="جرّب الآن"
          />
          <Plan
            highlight
            name="احترافي"
            price="29"
            features={[
              "كل الميزات الأساسية",
              "قوالب مميزة",
              "خصومات وأكواد",
              "تكاملات دفع وشحن متقدمة",
              "تقارير وتحليل��ت كاملة",
            ]}
            cta="ابدأ مجانًا"
          />
        </div>
        <div className="mt-10 text-center text-sm text-muted-foreground">
          لا توجد رسوم خفية. يمكنك الترقية أو الإلغاء في أي وقت.
        </div>
      </section>

      {/* FAQ (short) */}
      <section id="الأسئلة" className="container mx-auto px-4 py-12 sm:py-16">
        <div className="mx-auto max-w-4xl">
          <h3 className="text-2xl font-bold">{t("faq.title")}</h3>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <Faq q="هل أحتاج لتنصيب برامج؟" a="لا. walidstore يعمل بالكامل كسحابة SaaS من المتصفح فقط." />
            <Faq q="هل يدعم اللغة العربية؟" a="نعم، المنصة تدعم العربية بشكل كامل مع اتجاه RTL." />
            <Faq q="هل أستطيع ربط بوابة الدفع الخاصة بي؟" a="بالطبع، ندعم أشهر بوابات الدفع والتكامل عبر API." />
            <Faq q="هل هناك باقة مؤسسات؟" a="نعم، تواصل معنا لخطط مخصصة حسب احتياجك." />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(800px_400px_at_50%_-10%,hsl(var(--primary)/0.25),transparent)]" />
        <div className="container mx-auto px-4 py-16 sm:py-24">
          <div className="mx-auto max-w-3xl rounded-2xl border bg-card p-8 text-center shadow-sm">
            <h3 className="text-2xl font-extrabold tracking-tight">ابدأ رحلتك اليوم مع walidstore</h3>
            <p className="mt-2 text-muted-foreground">أنشئ متجرًا احترافيًا خلال دقائق، وابدأ البيع بثقة.</p>
            <div className="mt-6 flex items-center justify-center gap-3">
              <a href="/app">
                <Button className="px-6">{t("cta.start")}</Button>
              </a>
              <a href="#مزايا">
                <Button variant="outline" className="px-6">{t("cta.features")}</Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border bg-card p-6 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-start gap-4">
        <div className="rounded-lg bg-primary/10 p-3 text-primary transition-colors group-hover:bg-primary/15">
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-bold leading-6">{title}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
        </div>
      </div>
    </div>
  );
}

function Arch({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="rounded-2xl border bg-card p-5 text-center shadow-sm">
      <div className="mx-auto mb-2 h-1.5 w-12 rounded-full bg-primary/70" />
      <h4 className="font-bold">{title}</h4>
      <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function Plan({ name, price, features, cta, highlight }: { name: string; price: string; features: string[]; cta: string; highlight?: boolean }) {
  return (
    <div className={`relative rounded-2xl border bg-card p-6 shadow-sm ${highlight ? "ring-2 ring-primary" : ""}`}>
      {highlight && (
        <span className="absolute -top-3 left-4 rounded-full bg-primary px-3 py-1 text-xs text-primary-foreground">الأكثر شعبية</span>
      )}
      <div className="flex items-baseline justify-between">
        <h4 className="text-xl font-bold">{name}</h4>
        <div className="text-3xl font-extrabold">${price}<span className="text-sm font-medium text-muted-foreground">/شهريًا</span></div>
      </div>
      <ul className="mt-4 space-y-2 text-sm">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <span className="mt-1 h-3 w-3 rounded-full bg-primary" />
            <span>{f}</span>
          </li>
        ))}
      </ul>
      <div className="mt-6">
        <a href="/app">
          <Button className="w-full">{cta}</Button>
        </a>
      </div>
    </div>
  );
}

function Faq({ q, a }: { q: string; a: string }) {
  return (
    <div className="rounded-xl border bg-card p-5 shadow-sm">
      <h4 className="font-bold">{q}</h4>
      <p className="mt-1 text-sm text-muted-foreground">{a}</p>
    </div>
  );
}
