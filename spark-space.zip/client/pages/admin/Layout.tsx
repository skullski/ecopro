import { Link, Outlet, useLocation } from "react-router-dom";
import { useTranslation } from "@/lib/i18n";
import { useEffect, useState } from "react";

export default function AdminLayout() {
  const { t } = useTranslation();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('adminSidebarCollapsed') === 'true';
    } catch { return false; }
  });
  const location = useLocation();

  useEffect(() => {
    // Auto expand sidebar when leaving admin orders if user prefers
    try { localStorage.setItem('adminSidebarCollapsed', collapsed ? 'true' : 'false'); } catch {}
  }, [collapsed]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto flex gap-6 py-10">
        {!collapsed && (
          <aside className="w-64 rounded-xl border bg-card p-4">
            <h4 className="font-bold mb-4">لوحة المسؤول</h4>
            <nav className="flex flex-col gap-2 text-sm">
              <Link to="/admin" className="text-foreground/90 hover:text-foreground">ل��حة التحكم</Link>
              <Link to="/admin/products" className="text-foreground/90 hover:text-foreground">المنتجات</Link>
              <Link to="/admin/orders" className="text-foreground/90 hover:text-foreground">الطلبات</Link>
              <Link to="/admin/analytics" className="text-foreground/90 hover:text-foreground">التحليلات</Link>
              <Link to="/admin/stores" className="text-foreground/90 hover:text-foreground">المتاجر</Link>
              <Link to="/admin/settings" className="text-foreground/90 hover:text-foreground">الإعدادات</Link>
              <Link to="/admin/wasselni-settings" className="text-foreground/90 hover:text-foreground">Wasselni</Link>
              <Link to="/admin/calls" className="text-foreground/90 hover:text-foreground">المكالمات</Link>
            </nav>
          </aside>
        )}

        <section className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <button onClick={() => setCollapsed((s) => !s)} className="rounded-md border px-3 py-1 text-sm">
                {collapsed ? 'إظهار الشريط' : 'إخفاء الشريط'}
              </button>
              <h1 className="text-xl font-bold">{location.pathname.includes('/admin') ? 'لوحة المسؤول' : ''}</h1>
            </div>
          </div>
          <Outlet />
        </section>
      </div>
    </div>
  );
}
