import { useEffect, useState } from "react";
import { MoreHorizontal, Download, Filter } from "lucide-react";

export default function OrdersAdmin() {
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(()=>{
    const existing = JSON.parse(localStorage.getItem('orders')||'[]');
    // seed sample if empty
    if(!existing.length){
      const sample = [
        { id: 'ORD-001', customer: 'أحمد محمد', total: 15500, status: 'confirmed', time: 'منذ 5 دقائق' },
        { id: 'ORD-002', customer: 'فاطمة علي', total: 8200, status: 'confirmed', time: 'منذ 15 دقيقة' },
        { id: 'ORD-003', customer: 'محمود سارة', total: 22000, status: 'pending', time: 'منذ 30 دقيقة' },
        { id: 'ORD-004', customer: 'ليلى حسن', total: 12800, status: 'confirmed', time: 'منذ ساعة' },
        { id: 'ORD-005', customer: 'سليم عمر', total: 5500, status: 'failed', time: 'منذ ساعتين' },
      ];
      localStorage.setItem('orders', JSON.stringify(sample));
      setOrders(sample);
    } else setOrders(existing);
  },[]);

  function setStatus(id:string, status:string){
    const all = JSON.parse(localStorage.getItem('orders')||'[]');
    const next = all.map((o:any)=> o.id===id ? {...o, status} : o);
    localStorage.setItem('orders', JSON.stringify(next));
    setOrders(next);
  }

  return (
    <div className="rounded-2xl bg-[#0f1724] p-6 text-white">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold">آخر الطلبات</h3>
        <div className="flex items-center gap-2">
          <button className="rounded-md border px-3 py-1 inline-flex items-center gap-2"><Download className="h-4 w-4"/> تحميل</button>
          <button className="rounded-md border px-3 py-1 inline-flex items-center gap-2"><Filter className="h-4 w-4"/> تصفية</button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full table-fixed text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-300/80">
              <th className="p-3">رقم الطلب</th>
              <th className="p-3">العميل</th>
              <th className="p-3">المبلغ</th>
              <th className="p-3">الحالة</th>
              <th className="p-3">الوقت</th>
              <th className="p-3">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o:any)=> (
              <tr key={o.id} className="border-t border-slate-700/40">
                <td className="p-3">{o.id}</td>
                <td className="p-3">{o.customer}</td>
                <td className="p-3 font-extrabold">{o.total} دج</td>
                <td className="p-3">
                  {o.status === 'confirmed' && <span className="inline-flex items-center gap-2 text-green-300">● مؤكد</span>}
                  {o.status === 'pending' && <span className="inline-flex items-center gap-2 text-amber-300">● قيد الانتظار</span>}
                  {o.status === 'failed' && <span className="inline-flex items-center gap-2 text-red-400">● فشل</span>}
                </td>
                <td className="p-3 text-slate-300">{o.time}</td>
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    <button onClick={() => setStatus(o.id, 'confirmed')} className="rounded-md bg-green-600 px-2 py-1 text-xs">تأكيد</button>
                    <button onClick={() => setStatus(o.id, 'failed')} className="rounded-md bg-red-600 px-2 py-1 text-xs">إلغاء</button>
                    <button onClick={() => setStatus(o.id, 'followup')} className="rounded-md border px-2 py-1 text-xs">متابعة</button>
                    <button className="p-1"><MoreHorizontal className="h-4 w-4 text-slate-300"/></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex items-center justify-between text-sm text-slate-400">
        <div>عرض 1-5 من {orders.length} طلب</div>
        <div className="flex items-center gap-2">
          <button className="rounded-md border px-3 py-1">السابق</button>
          <button className="rounded-md bg-primary px-3 py-1 text-primary-foreground">التالي</button>
        </div>
      </div>
    </div>
  )
}
