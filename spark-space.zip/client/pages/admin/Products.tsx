import { useEffect, useState } from "react";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

export default function ProductsAdmin() {
  const [products, setProducts] = useState<any[]>([]);
  const [editing, setEditing] = useState<any | null>(null);

  useEffect(() => {
    setProducts(JSON.parse(localStorage.getItem("products") || "[]"));
  }, []);

  function save(p:any) {
    const all = JSON.parse(localStorage.getItem("products") || "[]");
    if (p.id) {
      const idx = all.findIndex((x:any)=>x.id===p.id);
      all[idx] = p;
    } else {
      p.id = Date.now().toString();
      all.push(p);
    }
    localStorage.setItem("products", JSON.stringify(all));
    setProducts(all);
    setEditing(null);
  }

  function remove(id:string) {
    const all = JSON.parse(localStorage.getItem("products") || "[]");
    const next = all.filter((x:any)=>x.id!==id);
    localStorage.setItem("products", JSON.stringify(next));
    setProducts(next);
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">المنتجات</h2>
        <Button onClick={()=>setEditing({})}>إنشاء منتج</Button>
      </div>

      <div className="mt-6 grid gap-4">
        {products.map((p)=>(
          <div key={p.id} className="flex items-center justify-between rounded-md border bg-card p-3">
            <div>
              <div className="font-bold">{p.title}</div>
              <div className="text-sm text-muted-foreground">${p.price}</div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={()=>setEditing(p)}>تعديل</Button>
              <Button variant="destructive" onClick={()=>remove(p.id)}>حذف</Button>
            </div>
          </div>
        ))}
      </div>

      {editing && <ProductForm product={editing} onSave={save} onCancel={()=>setEditing(null)} />}
    </div>
  );
}

function ProductForm({ product, onSave, onCancel }: any) {
  const [title, setTitle] = useState(product?.title||"");
  const [price, setPrice] = useState(product?.price||0);
  const [desc, setDesc] = useState(product?.desc||"");
  const [storeId, setStoreId] = useState(product?.storeId||"");
  const [stores, setStores] = useState<any[]>([]);

  useEffect(()=>{
    setStores(JSON.parse(localStorage.getItem('stores')||'[]'));
  },[]);

  function submit(e:any){
    e.preventDefault();
    onSave({ ...product, title, price: Number(price), desc, storeId });
  }

  return (
    <form onSubmit={submit} className="mt-6 rounded-lg border bg-card p-4">
      <div className="grid gap-3">
        <label className="text-sm">اسم المنتج</label>
        <input value={title} onChange={(e)=>setTitle(e.target.value)} className="rounded-md border px-3 py-2" />
        <label className="text-sm">السعر</label>
        <input type="number" value={price} onChange={(e)=>setPrice(e.target.value)} className="rounded-md border px-3 py-2" />
        <label className="text-sm">الوصف</label>
        <textarea value={desc} onChange={(e)=>setDesc(e.target.value)} className="rounded-md border px-3 py-2" />
        <label className="text-sm">تبعاً لأي متجر</label>
        <select value={storeId} onChange={(e)=>setStoreId(e.target.value)} className="rounded-md border px-3 py-2">
          <option value="">عام (غير مقيّد)</option>
          {stores.map(s=> (
            <option key={s.id} value={s.id}>{s.name} — {s.id}</option>
          ))}
        </select>
        <div className="flex items-center gap-2">
          <Button type="submit">حفظ</Button>
          <Button variant="ghost" onClick={onCancel}>إلغاء</Button>
        </div>
      </div>
    </form>
  );
}
