export default function Analytics() {
  const orders = JSON.parse(localStorage.getItem("orders")||"[]");
  const revenue = orders.reduce((s:any,o:any)=>s + (o.total||0), 0);
  const totalOrders = orders.length;
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">التحليلات</h2>
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground">الطلبات</div>
          <div className="mt-2 text-2xl font-extrabold">{totalOrders}</div>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground">إجمالي العائد</div>
          <div className="mt-2 text-2xl font-extrabold">${revenue}</div>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <div className="text-sm text-muted-foreground">معدّل التحويل</div>
          <div className="mt-2 text-2xl font-extrabold">{totalOrders ? Math.round((totalOrders / 100) * 100) : 0}%</div>
        </div>
      </div>

      <div className="mt-6 rounded-lg border bg-card p-4">
        <h3 className="font-bold">ملاحظات</h3>
        <p className="mt-2 text-sm text-muted-foreground">هذه بيانات تجريبية. سيتم ربط تحليلات حقيقية بعد توصيل خدمات التحليلات.</p>
      </div>
    </div>
  );
}
