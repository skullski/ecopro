import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Checkout() {
  const navigate = useNavigate();
  const cart = JSON.parse(localStorage.getItem("cart") || "[]");
  const total = cart.reduce((s:any,i:any)=>s + (i.price || 0), 0);

  function placeOrder(){
    const orders = JSON.parse(localStorage.getItem('orders')||'[]');
    const id = Date.now().toString();
    const order = { id, items: cart, total, status: 'pending', createdAt: Date.now() };
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    localStorage.removeItem('cart');
    navigate(`/order-success/${id}`);
  }

  if (!cart.length) return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-md text-center">
        <h2 className="text-2xl font-bold">عربة التسوق فارغة</h2>
      </div>
    </section>
  );

  return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-2xl">
        <h2 className="text-2xl font-bold mb-4">الدفع</h2>
        <div className="rounded-lg border bg-card p-4">
          <ul>
            {cart.map((i:any, idx:number)=> (
              <li key={idx} className="flex items-center justify-between py-2">
                <div>{i.name}</div>
                <div>${i.price}</div>
              </li>
            ))}
          </ul>
          <div className="mt-4 flex items-center justify-between">
            <div className="font-bold">المجموع</div>
            <div className="font-extrabold">${total}</div>
          </div>
          <div className="mt-4">
            <Button onClick={placeOrder}>تأكيد الطلب</Button>
          </div>
        </div>
      </div>
    </section>
  );
}
