import { useParams, Link } from "react-router-dom";

export default function Storefront(){
  const { id } = useParams();
  const stores = JSON.parse(localStorage.getItem('stores')||'[]');
  const store = stores.find((s:any)=>s.id===id);

  if (!store) return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-md text-center">
        <h2 className="text-2xl font-bold">المتجر غير موجود</h2>
        <p className="mt-2 text-muted-foreground">تأكد من رابط المتجر أو تواصل مع الدعم.</p>
      </div>
    </section>
  );

  // sample products for store
  const products = JSON.parse(localStorage.getItem('products')||'[]').filter((p:any)=> p.storeId ? p.storeId === store.id : true);

  return (
    <section className="container mx-auto py-20">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{store.name}</h1>
            <p className="text-sm text-muted-foreground">بواسطة {store.owner}</p>
          </div>
          <div>
            <Link to={`/shop/${store.id}/dashboard`} className="text-sm text-primary underline">لوحة الزبائن</Link>
          </div>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p:any)=> (
            <div key={p.id} className="rounded-lg border bg-card p-4">
              <div className="h-40 w-full rounded-md bg-muted/30" />
              <h3 className="mt-4 font-bold">{p.title}</h3>
              <div className="mt-2 flex items-center justify-between">
                <div className="text-lg font-extrabold">${p.price}</div>
                <Link to={`/product/${p.id}`} className="text-sm underline">عرض</Link>
              </div>
            </div>
          ))}
          {!products.length && <div className="text-muted-foreground">لا توجد منتجات في هذا المتجر بعد</div>}
        </div>
      </div>
    </section>
  );
}
