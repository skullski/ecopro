import React, { createContext, useContext, useEffect, useState } from "react";

type Locale = "ar" | "en" | "fr";

const translations: Record<Locale, Record<string, string | string[]>> = {
  ar: {
    "brand": "walidstore",
    "hero.badge": "منصة SaaS للمتاجر الإلكترونية",
    "hero.title": "walidstore: أنشئ متجرًا إلكترونيًا احترافيًا وأدِر مبيعاتك من مكان واحد",
    "hero.desc": "منصة متكاملة لتصميم، إدارة وتسويق متجرك بسهولة عبر الإنترنت.",
    "cta.features": "استعراض المزايا",
    "cta.pricing": "التسعير",
    "features.title": "كل ما تحتاجه للنجاح",
    "features.desc": "من التصميم إلى إدارة المخزون والمدفوعات والشحن والتسويق — walidstore يوفر الأدوات كاملة.",
    "architecture.title": "البنية العامة لمنصة walidstore",
    "pricing.title": "أسعار بسيطة وواضحة",
    "faq.title": "أسئلة شائعة",
    "cta.start": "ابدأ الآن",
    "login": "دخول",
    "signup": "إنشاء حساب",
    "logout": "تسجيل الخروج",
    "store.title": "المتجر",
    "store.empty": "لا يوجد منتجات حالياً",
    "footer.copyright": "© {year} walidstore. جميع الحقوق محفوظة.",
    "wasselni.title": "Wasselni - نظام تأكيد الطلبات الذكي",
    "wasselni.desc": "نظام ذكي لأصحاب المتاجر للتأكيد الآلي للمكالمات الصوتية باللهجة المحلية.",
    "wasselni.example": "السلام عليكم، مرحبا بيك خويا [اسم الزبون]، معاك [اسم المتجر]، نحب نأكد الطلبية نتاعك تاع [اسم المنتج]، واش رأيك؟",
    "admin.wasselni.title": "إعدادات Wasselni",
    "admin.calls.title": "قائمة المكالمات",
    "admin.calls.empty": "لا توجد مكالمات مجدولة حاليا��",
  },
  en: {
    "brand": "walidstore",
    "hero.badge": "SaaS platform for online stores",
    "hero.title": "walidstore — Build a professional online store and manage sales from one place",
    "hero.desc": "All-in-one platform for designing, managing and marketing your store online.",
    "cta.features": "Explore features",
    "cta.pricing": "Pricing",
    "features.title": "Everything you need to succeed",
    "features.desc": "From design to inventory, payments, shipping and marketing — walidstore has you covered.",
    "architecture.title": "Walidstore architecture",
    "pricing.title": "Simple, transparent pricing",
    "faq.title": "FAQ",
    "cta.start": "Get started",
    "login": "Login",
    "signup": "Sign up",
    "logout": "Logout",
    "store.title": "Store",
    "store.empty": "No products yet",
    "footer.copyright": "© {year} walidstore. All rights reserved.",
    "wasselni.title": "Wasselni - Smart Call Confirmation System",
    "wasselni.desc": "AI-driven voice calls to confirm orders in local dialects.",
    "wasselni.example": "Hello, this is [store] calling to confirm your order of [product]. Are you still interested?",
    "admin.wasselni.title": "Wasselni Settings",
    "admin.calls.title": "Call Queue",
    "admin.calls.empty": "No scheduled calls",
  },
  fr: {
    "brand": "walidstore",
    "hero.badge": "Plateforme SaaS pour boutiques en ligne",
    "hero.title": "walidstore — Créez une boutique en ligne professionnelle et gérez vos ventes depuis un seul endroit",
    "hero.desc": "Plateforme tout-en-un pour concevoir, gérer et promouvoir votre boutique en ligne.",
    "cta.features": "Voir les fonctionnalités",
    "cta.pricing": "Tarifs",
    "features.title": "Tout ce dont vous avez besoin pour réussir",
    "features.desc": "Du design à l'inventaire, paiements, expédition et marketing — walidstore vous couvre.",
    "architecture.title": "Architecture de walidstore",
    "pricing.title": "Tarification simple et transparente",
    "faq.title": "FAQ",
    "cta.start": "Commencer",
    "login": "Connexion",
    "signup": "S'inscrire",
    "logout": "Déconnexion",
    "store.title": "Boutique",
    "store.empty": "Aucun produit pour le moment",
    "footer.copyright": "© {year} walidstore. Tous droits réservés.",
    "wasselni.title": "Wasselni - Système de confirmation d'appels intelligent",
    "wasselni.desc": "Appels vocaux pilotés par IA pour confirmer les commandes en dialecte local.",
    "wasselni.example": "Bonjour, c'est [boutique], nous confirmons votre commande [produit]. Êtes-vous toujours intéressé ?",
    "admin.wasselni.title": "Paramètres Wasselni",
    "admin.calls.title": "File d'appels",
    "admin.calls.empty": "Aucun appel planifié",
  },
};

const I18nContext = createContext<any>(null);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocale] = useState<Locale>(() => {
    try {
      const stored = localStorage.getItem("locale");
      return (stored as Locale) || "ar";
    } catch {
      return "ar";
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("locale", locale);
      // set dir attribute for RTL languages
      if (typeof document !== "undefined") {
        document.documentElement.lang = locale === "ar" ? "ar" : locale === "fr" ? "fr" : "en";
        document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
      }
    } catch {}
  }, [locale]);

  function t(key: string) {
    const v = translations[locale][key];
    if (!v) return key;
    return v;
  }

  return <I18nContext.Provider value={{ locale, setLocale, t }}>{children}</I18nContext.Provider>;
}

export function useTranslation() {
  return useContext(I18nContext);
}
