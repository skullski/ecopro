import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import useTheme from "@/hooks/useTheme";
import { useTranslation } from "@/lib/i18n";

export default function Header() {
  const { toggle, theme } = useTheme();
  const { locale, setLocale, t } = useTranslation();
  const navigate = useNavigate();

  const user = typeof window !== "undefined" ? JSON.parse(localStorage.getItem("user") || "null") : null;
  const isAdmin = typeof window !== "undefined" ? localStorage.getItem("isAdmin") === 'true' : false;

  function handleLogout() {
    localStorage.removeItem("user");
    localStorage.removeItem("isAdmin");
    navigate("/");
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">W</span>
          <span className="capitalize">{t("brand")}</span>
        </Link>
        <nav className="hidden gap-6 text-sm font-medium md:flex">
          <a href="/#مزايا" className="text-foreground/80 hover:text-foreground">المزايا</a>
          <a href="/#البنية" className="text-foreground/80 hover:text-foreground">البنية</a>
          <a href="/#الأسعار" className="text-foreground/80 hover:text-foreground">الأسعار</a>
          <a href="/#الأسئلة" className="text-foreground/80 hover:text-foreground">الأسئلة</a>
          <Link to="/store" className="text-foreground/80 hover:text-foreground">{t("store.title")}</Link>
          {isAdmin && <Link to="/admin" className="text-foreground/80 hover:text-foreground">لوحة المسؤول</Link>}
        </nav>
        <div className="flex items-center gap-3">
          {/* language selector */}
          <select value={locale} onChange={(e) => setLocale(e.target.value)} className="hidden rounded-md border px-2 py-1 text-sm md:inline-block">
            <option value="ar">العربية</option>
            <option value="en">EN</option>
            <option value="fr">FR</option>
          </select>

          {/* theme toggle */}
          <button onClick={toggle} aria-label="toggle theme" className="rounded-md border px-2 py-1 text-sm">
            {theme === "dark" ? "☾" : "☼"}
          </button>

          {!user ? (
            <>
              <Link to="/login" className="hidden md:inline-block">
                <Button variant="ghost">{t("login")}</Button>
              </Link>
              <Link to="/signup">
                <Button>{t("signup")}</Button>
              </Link>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => navigate("/app")}>
                لوحة التحكم
              </Button>
              <Button variant="outline" onClick={handleLogout}>{t("logout")}</Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
