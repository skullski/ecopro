import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import Index from "./pages/Index";
import AppPlaceholder from "./pages/AppPlaceholder";
import NotFound from "./pages/NotFound";
import { I18nProvider } from "@/lib/i18n";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Store from "./pages/Store";
import Product from "./pages/Product";
import Checkout from "./pages/Checkout";
import OrderSuccess from "./pages/OrderSuccess";
import AdminLayout from "./pages/admin/Layout";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminProducts from "./pages/admin/Products";
import AdminOrders from "./pages/admin/Orders";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminSettings from "./pages/admin/Settings";
import Billing from "./pages/Billing";
import AdminBilling from "./pages/admin/Billing";
import Wasselni from "./pages/Wasselni";
import AdminWasselniSettings from "./pages/admin/WasselniSettings";
import AdminCalls from "./pages/admin/Calls";
import AdminStores from "./pages/admin/Stores";
import Storefront from "./pages/Storefront";
import CustomerDashboard from "./pages/customer/Dashboard";
import CustomerLogin from "./pages/customer/Login";
import CustomerSignup from "./pages/customer/Signup";


const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <I18nProvider>
        <BrowserRouter>
          <Layout>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/app" element={<AppPlaceholder />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/store" element={<Store />} />
              <Route path="/product/:id" element={<Product />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/order-success/:id" element={<OrderSuccess />} />

              {/* Admin routes (require admin role) */}
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<AdminDashboard />} />
                <Route path="products" element={<AdminProducts />} />
                <Route path="orders" element={<AdminOrders />} />
                <Route path="analytics" element={<AdminAnalytics />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="stores" element={<AdminStores />} />
                <Route path="billing" element={<AdminBilling />} />
                <Route path="wasselni-settings" element={<AdminWasselniSettings />} />
                <Route path="calls" element={<AdminCalls />} />
              </Route>
              <Route path="/billing" element={<Billing />} />
              <Route path="/wasselni" element={<Wasselni />} />
              <Route path="/s/:id" element={<Storefront />} />
              <Route path="/shop/:id/dashboard" element={<CustomerDashboard />} />
              <Route path="/shop/:id/login" element={<CustomerLogin />} />
              <Route path="/shop/:id/signup" element={<CustomerSignup />} />

              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </I18nProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

const container = document.getElementById("root")!;
// Persist root across HMR to avoid 'createRoot on same container' warning
declare global {
  interface Window {
    __APP_ROOT__?: ReturnType<typeof createRoot>;
  }
}
if (!window.__APP_ROOT__) {
  window.__APP_ROOT__ = createRoot(container);
}
window.__APP_ROOT__.render(<App />);
